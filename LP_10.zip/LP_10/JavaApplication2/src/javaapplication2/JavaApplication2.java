package javaapplication2;

import java.awt.BorderLayout;
import java.awt.Frame;
import javax.swing.*;
/**
 *
 * @author Zero
 */

public class JavaApplication2 extends JFrame{
    /**
     * @param args the command line arguments
     */
    JButton nButton = new JButton("North");
    JButton sButton = new JButton("South");
    JButton eButton = new JButton("East");
    JButton wButton = new JButton("West");
    JButton cButton = new JButton("Center");
    
public JavaApplication2 (){
    super("Border Layout Beraksi");
    setSize(260,300);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(nButton, BorderLayout.NORTH);
        add(sButton, BorderLayout.SOUTH);
        add(eButton, BorderLayout.EAST);
        add(wButton, BorderLayout.WEST);
        add(cButton, BorderLayout.CENTER);
}
    public static void main(String[] args) {
        JavaApplication2 frame = new JavaApplication2();
        frame.setVisible(true);
    }
    
}
