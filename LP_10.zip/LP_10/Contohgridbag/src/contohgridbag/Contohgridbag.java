package contohgridbag;

import java.awt.Button;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.*;
/**
 *
 * @author Zero
 */
public class Contohgridbag extends JFrame {
    public static void main(String[] args) {
        // TODO code application logic here
        Contohgridbag a = new Contohgridbag();
    }
    
    public Contohgridbag() {
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        setLayout(grid);
        setTitle("GridBag Layout Example");
        GridBagLayout layout = new GridBagLayout();
        this.setLayout(layout);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 1;
        this.add(new Button("Button One"), gbc);
        gbc.gridx = 2;
        gbc.gridy = 1;
        this.add(new Button("Button Two"), gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipady = 30;
        gbc.gridx = 1;
        gbc.gridy = 2;
        this.add(new Button("Button Three"), gbc);
        gbc.gridx = 2;
        gbc.gridy = 2;
        this.add(new Button("Button Four"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 2;
        this.add(new Button("Button Five"), gbc);
        setSize(250, 250);
        setPreferredSize(getSize());
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
